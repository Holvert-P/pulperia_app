class ProductCatalogExportResult {
  const ProductCatalogExportResult({
    required this.filePath,
    required this.productsCount,
    required this.exportedAt,
  });

  final String filePath;
  final int productsCount;
  final DateTime exportedAt;
}

class ProductCatalogImportResult {
  const ProductCatalogImportResult({
    required this.totalRead,
    required this.created,
    required this.updated,
    required this.skipped,
    required this.resetBeforeImport,
  });

  final int totalRead;
  final int created;
  final int updated;
  final int skipped;
  final bool resetBeforeImport;

  int get applied => created + updated;

  bool get hasChanges => applied > 0 || resetBeforeImport;
}
