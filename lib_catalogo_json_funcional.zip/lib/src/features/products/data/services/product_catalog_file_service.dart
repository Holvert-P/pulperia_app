import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

class ProductCatalogFileService {
  const ProductCatalogFileService();

  Future<String> pickJsonContent() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['json'],
      withData: true,
    );

    if (result == null || result.files.isEmpty) {
      throw const ProductCatalogFileCancelledException();
    }

    final file = result.files.single;
    final bytes = file.bytes;
    if (bytes != null) {
      return utf8.decode(bytes);
    }

    final path = file.path;
    if (path == null || path.isEmpty) {
      throw const ProductCatalogFileException(
        'No se pudo leer el archivo seleccionado.',
      );
    }

    return File(path).readAsString();
  }

  Future<File> saveExportedJson(String jsonContent) async {
    final directory = await getApplicationDocumentsDirectory();
    final fileName = _buildExportFileName(DateTime.now());
    final file = File('${directory.path}/$fileName');
    return file.writeAsString(jsonContent, flush: true);
  }

  Future<void> shareFile(File file) async {
    await Share.shareXFiles(
      [XFile(file.path, mimeType: 'application/json')],
      text: 'Catálogo de productos exportado desde Pulpería Pérez',
    );
  }

  String _buildExportFileName(DateTime date) {
    String two(int value) => value.toString().padLeft(2, '0');
    return 'productos_catalogo_${date.year}_${two(date.month)}_${two(date.day)}_${two(date.hour)}_${two(date.minute)}.json';
  }
}

class ProductCatalogFileException implements Exception {
  const ProductCatalogFileException(this.message);

  final String message;

  @override
  String toString() => message;
}

class ProductCatalogFileCancelledException implements Exception {
  const ProductCatalogFileCancelledException();
}
