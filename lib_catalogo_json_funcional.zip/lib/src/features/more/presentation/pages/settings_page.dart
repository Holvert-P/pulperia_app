import 'package:app/src/features/more/presentation/controllers/catalog_settings_controller.dart';
import 'package:app/src/features/more/presentation/widgets/settings_option_tile.dart';
import 'package:app/src/features/more/presentation/widgets/settings_section_title.dart';
import 'package:app/src/features/products/domain/entities/product_catalog_io_result.dart';
import 'package:app/src/shared/widgets/widgets.dart';
import 'package:flutter/material.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  static const routeName = '/settings';

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final CatalogSettingsController _catalogController;

  @override
  void initState() {
    super.initState();
    _catalogController = CatalogSettingsController();
  }

  @override
  void dispose() {
    _catalogController.dispose();
    super.dispose();
  }

  Future<void> _exportProducts() async {
    try {
      final result = await _catalogController.exportProducts();
      if (!mounted) return;
      _showSuccess(
        'Catálogo exportado: ${result.productsCount} productos. Archivo: ${result.filePath}',
      );
    } catch (error) {
      if (!mounted) return;
      _showError('No se pudo exportar el catálogo. $error');
    }
  }

  Future<void> _importProducts() async {
    try {
      final result = await _catalogController.importProducts();
      if (!mounted || result == null) return;
      _showImportResult(result);
    } catch (error) {
      if (!mounted) return;
      _showError('No se pudo importar el catálogo. Revisa que el JSON sea válido.');
    }
  }

  Future<void> _resetCatalog() async {
    final confirmed = await showConfirmationBottomSheet(
      context: context,
      icon: Icons.warning_amber_outlined,
      title: 'Reinicializar catálogo',
      headline: '¿Borrar productos actuales y cargar el JSON maestro?',
      supportingText:
          'Esta acción reemplaza el catálogo actual. Exporta una copia antes si quieres conservar cambios.',
      confirmLabel: 'Reinicializar',
      confirmIcon: Icons.restart_alt_outlined,
    );

    if (confirmed != true) return;

    try {
      final result = await _catalogController.resetCatalog();
      if (!mounted) return;
      _showImportResult(result);
    } catch (error) {
      if (!mounted) return;
      _showError('No se pudo reinicializar el catálogo. $error');
    }
  }

  void _showImportResult(ProductCatalogImportResult result) {
    final verb = result.resetBeforeImport ? 'reinicializado' : 'importado';
    _showSuccess(
      'Catálogo $verb. Nuevos: ${result.created}, actualizados: ${result.updated}, omitidos: ${result.skipped}.',
    );
  }

  void _showPending(String feature) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$feature estará disponible pronto')),
    );
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Theme.of(context).colorScheme.error,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _catalogController,
      builder: (context, _) {
        final working = _catalogController.working;

        return Scaffold(
          appBar: AppBar(title: const Text('Configuración')),
          body: Stack(
            children: [
              ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  const SettingsSectionTitle('Negocio'),
                  Card(
                    child: Column(
                      children: [
                        SettingsOptionTile(
                          icon: Icons.storefront_outlined,
                          title: 'Datos del negocio',
                          subtitle: 'Nombre, subtítulo, logo y datos generales',
                          onTap: working
                              ? null
                              : () => _showPending('Datos del negocio'),
                        ),
                        const Divider(height: 1),
                        SettingsOptionTile(
                          icon: Icons.request_quote_outlined,
                          title: 'Impuestos',
                          subtitle: 'IVA, moneda y preferencias fiscales',
                          onTap: working ? null : () => _showPending('Impuestos'),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  const SettingsSectionTitle('Catálogo'),
                  Card(
                    child: Column(
                      children: [
                        SettingsOptionTile(
                          icon: Icons.download_outlined,
                          title: 'Exportar productos a JSON',
                          subtitle:
                              'Genera un archivo con el catálogo actual para editarlo con IA',
                          onTap: working ? null : _exportProducts,
                        ),
                        const Divider(height: 1),
                        SettingsOptionTile(
                          icon: Icons.upload_file_outlined,
                          title: 'Importar productos desde JSON',
                          subtitle:
                              'Actualiza productos existentes y agrega productos nuevos',
                          onTap: working ? null : _importProducts,
                        ),
                        const Divider(height: 1),
                        SettingsOptionTile(
                          icon: Icons.restart_alt_outlined,
                          title: 'Reinicializar catálogo',
                          subtitle:
                              'Borra productos actuales y carga el JSON maestro incluido en la app',
                          danger: true,
                          onTap: working ? null : _resetCatalog,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              if (working)
                Container(
                  color: Theme.of(context)
                      .colorScheme
                      .surface
                      .withValues(alpha: 0.55),
                  child: const Center(child: CircularProgressIndicator()),
                ),
            ],
          ),
        );
      },
    );
  }
}
